﻿select datname
from pg_database
where datname = '#InitialCatalog#';