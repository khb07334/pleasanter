﻿create user "#Uid#" with login password '#Pwd#' valid until 'infinity';
alter role "#Uid#" set default_tablespace='#ServiceName#';