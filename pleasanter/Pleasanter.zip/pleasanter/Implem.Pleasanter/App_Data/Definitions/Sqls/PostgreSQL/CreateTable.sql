﻿#DropConstraint#
    create table "#TableName#"
    (
#Columns#
    );
#Pks#
#Defaults#
