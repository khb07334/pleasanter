﻿set xact_abort on;
begin transaction;
