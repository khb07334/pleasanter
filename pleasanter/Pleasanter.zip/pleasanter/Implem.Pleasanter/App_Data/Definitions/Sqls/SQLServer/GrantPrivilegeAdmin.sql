﻿use "#ServiceName#";
alter role "db_owner" add member "#Uid#";
