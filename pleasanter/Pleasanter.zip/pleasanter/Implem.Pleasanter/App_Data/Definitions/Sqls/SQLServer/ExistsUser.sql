﻿use "#ServiceName#";
select name from sysusers where name='#Uid#';