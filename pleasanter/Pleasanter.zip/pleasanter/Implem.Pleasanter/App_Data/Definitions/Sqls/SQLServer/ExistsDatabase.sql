﻿select name
from sys.databases
where name = '#InitialCatalog#';