﻿use "#ServiceName#";
alter role "db_datareader" add member "#Uid#";
alter role "db_datawriter" add member "#Uid#";
