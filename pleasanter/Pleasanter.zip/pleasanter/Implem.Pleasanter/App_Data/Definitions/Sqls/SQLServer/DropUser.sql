﻿use "#ServiceName#";
drop user "#Uid#";