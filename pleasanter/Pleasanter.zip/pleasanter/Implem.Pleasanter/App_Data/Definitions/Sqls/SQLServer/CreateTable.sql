﻿#DropConstraint#
    create table "dbo"."#TableName#"
    (
#Columns#
    );
#Pks#
#Defaults#
