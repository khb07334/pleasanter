﻿create login "#Uid#" with password='#Pwd#', default_database="#ServiceName#", check_expiration=off, check_policy=off;
alter login "#Uid#" enable;